function Compare()
{
    let a;
    a=parseInt(prompt("Enter the 1st value"));

    if (a%2==0 ) {
        document.getElementById("n").innerHTML='The Number '+a+' is Even.';
        document.getElementById("n").style.color='green';
    }
    else{
        document.getElementById("n").innerHTML='The Number '+a+' is Odd.';
        document.getElementById("n").style.color='red';
    }
}